# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.19-ndb-7.5.7-cluster-gpl)
# Database: CostumeConvention
# Generation Time: 2017-12-12 23:08:02 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table COSTUMES
# ------------------------------------------------------------

DROP TABLE IF EXISTS `COSTUMES`;

CREATE TABLE `COSTUMES` (
  `Cname` varchar(32) DEFAULT NULL,
  `CurrentCondition` int(11) unsigned DEFAULT NULL,
  `URL` varchar(250) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Pid` int(11) DEFAULT NULL,
  `Cid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Cid`),
  KEY `Pid` (`Pid`),
  CONSTRAINT `Pid` FOREIGN KEY (`Pid`) REFERENCES `Participant` (`Pid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

LOCK TABLES `COSTUMES` WRITE;
/*!40000 ALTER TABLE `COSTUMES` DISABLE KEYS */;

INSERT INTO `COSTUMES` (`Cname`, `CurrentCondition`, `URL`, `Description`, `Pid`, `Cid`)
VALUES
	('Left Shark',8,'http://pbs.twimg.com/media/B80RN-1CIAAcB7j.jpg','i can dance',1,1),
	('Panda',10,'https://images.halloweencostumes.com/products/8202/1-1/adult-panda-costume.jpg','git git git skuuurt',1,2),
	('Lion',2,'https://images-na.ssl-images-amazon.com/images/I/81Gcv42BBIL._UY589_.jpg','What is this. cutie',2,3),
	('Dan',8,'https://images-na.ssl-images-amazon.com/images/I/51vVNdWwxOL.jpg','Aligator nice costume',2,4),
	('Bunny ',4,'https://images-na.ssl-images-amazon.com/images/I/31JzlOjq%2BfL.jpg','Elmer Fud can\'t touch me',7,5),
	('Giraffe',5,'https://images.halloweencostumes.com/products/11969/1-1/adult-giraffe-costume.jpg','Gimme dat neck.',9,6),
	('Chicken',3,'http://www.costume-shop.com/images/products/22051.jpg','Peter Griffin thinks I\'m cocky',11,7),
	('Monkey',2,'https://images.halloweencostumes.com/products/11966/1-1/adult-funky-monkey-costume.jpg','Alwayse Increase Dah Size',11,8),
	('Zebra',6,'https://images-na.ssl-images-amazon.com/images/I/918pV0%2Bqf3L._UL1500_.jpg','Striped is the new black',NULL,11);

/*!40000 ALTER TABLE `COSTUMES` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Participant
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Participant`;

CREATE TABLE `Participant` (
  `Pid` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(32) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Sex` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`Pid`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

LOCK TABLES `Participant` WRITE;
/*!40000 ALTER TABLE `Participant` DISABLE KEYS */;

INSERT INTO `Participant` (`Pid`, `Username`, `Password`, `Sex`)
VALUES
	(1,'dan the man','12345','M'),
	(2,'Gage','1234','M'),
	(7,'Izzy','cat','F'),
	(9,'Izzy2','mjau','F'),
	(11,'Izzy3','dog','F'),
	(12,'Izzy4','bark','F'),
	(13,'Michelle','jag','F'),
	(14,'need','11','F'),
	(16,'micjag','j','M');

/*!40000 ALTER TABLE `Participant` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
