<?php
	//connect to database
	$conn=mysqli_connect('localhost', 'root', '1234', 'CostumeConvention') or die ("can't connect to mysql");

	$username = $_POST['username'];
	$oldpassword = $_POST['oldpassword'];
	$newpassword = $_POST['newpassword'];
	
	$username = mysqli_real_escape_string($conn, $username);
	$oldpassword = mysqli_real_escape_string($conn, $oldpassword);
	$newpassword = mysqli_real_escape_string($conn, $newpassword);

	//return all  entries where username=$username and password=$password
	$sql="SELECT * FROM Participant WHERE Username LIKE '$username' AND Password LIKE '$oldpassword' ";

	$returnval=$conn->query($sql);
	$num_row = mysqli_num_rows($returnval);
	if($num_row == 1){  //if exctly one user found;
		$update="UPDATE Participant SET Password='$newpassword' WHERE Username LIKE '$username' ";
		$return=$conn->query($update);
		header('Location: frontpage.php');
		//}
	}else {
		//invalid
		header('Location: updateLogin.html');
	}
	//mysqli_close($conn)
?>